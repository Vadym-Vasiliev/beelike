import * as flsFunctions from "./modules/functions.js";

import "./calculate-select.js";
import "./burger-menu.js";
import "./slider.js";
import "./validator.js";
import "./animation.js";

flsFunctions.isWebp();
