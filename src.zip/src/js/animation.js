import AOS from "aos";

AOS.init();
